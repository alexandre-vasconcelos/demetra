#!/bin/bash

echo -n "Executing this script will remove Unit Platform Direct Agent from your system, including any customized plugins that may exist. Are you sure you want to do this? (y/n): "
read answer

[[ "$answer" != "Y" && "$answer" != "y" ]] && echo "Exiting script. Unit Platform Direct Agent was not uninstalled." && exit 1

echo "Proceeding to uninstall Unit Platform Direct Agent..."

DEBUG=true

INSTALL_DIR="/opt/Netwall/DirectAgent"
INIT_SCRIPT="unit-platform-direct-agent"
INIT_SCRIPT_FILE="/etc/systemd/system/${INIT_SCRIPT}.service"

function printDebug(){
   if [ $DEBUG == true ]; then
      echo "$1"
   fi
}

if [ "$1" == "--quiet" ]; then
   DEBUG=false
fi

printDebug "Stopping agent..."
systemctl stop $INIT_SCRIPT
systemctl disable $INIT_SCRIPT

printDebug "Deleting '${INIT_SCRIPT_FILE}'..."
rm -f $INIT_SCRIPT_FILE

printDebug "Deleting '${INSTALL_DIR}'..."
rm -rf $INSTALL_DIR

printDebug "Done!"
exit 0
