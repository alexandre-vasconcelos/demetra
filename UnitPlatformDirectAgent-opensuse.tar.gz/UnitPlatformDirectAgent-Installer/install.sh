#!/bin/bash

AGENTS_ROOT="/opt/Netwall"
INSTALL_DIR="$AGENTS_ROOT/DirectAgent"
UUID_FILE="$AGENTS_ROOT/uuid.key"
BIN_DIR="$INSTALL_DIR/bin"
SYSTEMD_DIR="/etc/systemd/system/"
INIT_SCRIPT="unit-platform-direct-agent"
DEBUG=true

function printDebug(){
   if [ $DEBUG == true ]; then
      echo "$1"
   fi
}

##################################################################################
# OS detection
##################################################################################
function detect_os (){
    name=`uname -s`
    version=`uname -r`
    return_code=1
    distribution="unknown"

    if [ "$name" = "Linux" ]; then
		if test -f /etc/os-release; then
			source /etc/os-release
			case $ID in
	        	rhel|centos|fedora|debian|ubuntu|amzn|rocky)
					distribution=$ID
				;;
				*)
					# if the distro is not recognized, check if it is a derivative of Debian or RHEL
					distribution=$(echo "$ID_LIKE" | grep -Eo "debian|rhel")
					if [ -z "$distribution" ]; then
						distribution="unknown"
					else
						printDebug "WARNING: distro $ID ($PRETTY_NAME) is not supported, but it is a derivative of ${distribution}. Installation will continue." 
					fi
				;;
    		esac
		elif test -f /etc/redhat-release; then
	    	distribution="rhel"
        elif test -f /etc/redhat-version; then
    	    distribution="rhel"
		elif test -f /etc/fedora-release; then
    	    distribution="fedora"
        elif test -f /etc/debian_version; then
    	    distribution="debian"
        elif test -f /etc/debian-version; then
    	    distribution="debian"
        elif test -f /etc/system-release; then
    	    distribution="amzn"
        fi
    fi

	case $distribution in
        rhel|centos|fedora|debian|ubuntu|amzn|rocky)
    		return_code=0
		;;
    esac

    return $return_code
}

function symLink() {

	ldconfig

    lib=$(ldconfig -p | grep "${2}$")
    if [ $? -eq 0 ]; then
        lib=$(echo "${lib}" | cut -d '>' -f 2 | head -n1)
        libdir=$(dirname "${lib}")
        ln -s ${lib} ${libdir}/${1}
    fi
}

function checkReq() {
    executable="files/bin/UnitPlatformDirectAgent_x64"

    libs=$(ldd $executable | grep "not found$" | cut -d '=' -f 1)

    if [ "$libs" = "" ]; then
        printDebug "Checking library dependencies [ OK ]"
    else
	for i in $(echo "$libs"); do
	    [ "$i" = "libssl.so.3" ] && symLink "libssl.so.3" "libssl.so"
	    [ "$i" = "libcrypto.so.3" ] && symLink "libcrypto.so.3" "libcrypto.so"
	    [ "$i" = "libstdc++.so.6" ] && symLink "libstdc++.so.6" "libstdc++.so"
        done

        libs=$(ldd $executable | grep "not found$" | cut -d '=' -f 1)

	if [ "$libs" = "" ]; then
    	    printDebug "Checking library dependencies [ OK ]"
	else
            printDebug "Checking library dependencies [ FAILED ]"
	    for j in $(echo "$libs"); do
		printDebug "Lib $j not found."
    	    done
	    printDebug "Suggestions to install libs:"
    	    printDebug "- For lib libssl.so install the package openssl-devel on RedHat/CentOS/Fedora/AWS or libssl-dev on Debian/Ubuntu"
    	    printDebug "- For lib ld-linux.so install the package glibc on RedHat/CentOS/Fedora/AWS."
    	    printDebug "- For lib libcrypto.so install the package openssl-devel on RedHat/CentOS/Fedora/AWS."
    	    printDebug "- For lib libstdc++.so install the package libstdc++ on RedHat/CentOS/Fedora/AWS."
	    exit 1
	fi
    fi

    #Check if 'bc' command is available
    echo 1+1 | bc -l 2&>/dev/null
    if [ $? -eq 127 ]; then
        printDebug "Checking package dependencies [ FAILED ]"
        printDebug "The command 'bc' was not found."
        printDebug "Suggestions:"
        printDebug "- To install on RedHat/CentOS: yum install bc"
        printDebug "- To install on Debian/Ubuntu: apt-get install bc"
        exit 1
    fi

    #Check if 'uuidgen' command is available
    uuidgen 2&>/dev/null
    if [ $? -eq 127 ]; then
        printDebug "Checking package dependencies [ FAILED ]"
        printDebug "The command 'uuidgen' was not found."
        printDebug "Suggestions:"
        printDebug "- To install on Debian/Ubuntu: apt-get install uuid-runtime"
        exit 1
    fi
}

if [ "$1" == "--quiet" ]; then
  DEBUG=false
fi

if [ $(id -u) -ne 0 ]; then
  printDebug "You must be root to install the agent"
  exit 1
fi

if [ ! "$0" = "./install.sh" ]; then
  cd `dirname $0`
fi

detect_os
os_supported=$?

if [ $os_supported -ne 0 ];then

    echo -n "WARNING: Your operating system is not supported, some features may not work properly. Continue installation anyway? [y/n] "
	read answer

	if [[ "$answer" != "Y" && "$answer" != "y" ]]; then
		printDebug "Unit Platform Direct Agent will not be installed. Exiting."
    	exit 1
	fi

else
    printDebug "Distribution $distribution detected [ OK ]"
fi

bit=`uname -m`
if [ "$bit" = "x86_64" ]; then 
	printDebug "Detected $bit system [ OK ]"
else
	printDebug "This agent only supports x86_64 systems (detected $bit). [ FAILED ]"
	exit 1
fi

printDebug "Checking requirements..."
checkReq 

printDebug "Installing..."
mkdir -p $INSTALL_DIR

# Criacao do arquivo com o UUID
if ! [ -e $UUID_FILE ]; then
   uuidgen 1> "$UUID_FILE" 2> /dev/null
fi

cp -rf files/* ${INSTALL_DIR}/

# Criacao/atualizacao do libexec/
mkdir -p "$AGENTS_ROOT/libexec"
cp -rf libexec/* "$AGENTS_ROOT/libexec/"

# init file
cp -f files/init/* $SYSTEMD_DIR/
systemctl enable $INIT_SCRIPT
systemctl start $INIT_SCRIPT

printDebug "Instalation completed [ OK ]"
